#include <bits/stdc++.h>

const int N = 2000005;

bool used[2][N];

int main(int argc, char *argv[]) {
  int score = atoi(argv[4]);            // full score of this test case
  std::ifstream fin(argv[1]);         // where to read the input
  std::ifstream fstd(argv[3]);          // where to read the jury's answer
  std::ifstream fout(argv[2]);       // where to read the participant's output
  std::ofstream fscore(argv[5]);    // where to write the score
  std::ofstream freport(argv[6]);  // where to write the feedback information
  int n, m;
  fin >> n >> m;
  std::string str;
  fout >> str;
  if (str != "Yes") {
    freport << "There exist a solution!" << std::endl;
    fscore << 0 << std::endl;
    return 0;
  }
  for (int i = 0; i < n; ++i) {
    int x, y;
    fout >> x >> y;
    if (x >= n || x < 0 || y < m || y >= n + m) {
      freport << "Out of the bound!" << std::endl;
      fscore << 0 << std::endl;
    }
    if (used[0][x] || used[1][y]) {
      freport << "Not a match!" << std::endl;
      fscore << 0 << std::endl;
      return 0;
    }
    if ((x & y) != x) {
      freport << "Invalid match!" << std::endl;
      fscore << 0 << std::endl;
      return 0;
    }
    used[0][x] = used[1][y] = true;
  }
  freport << "OK!" << std::endl;
  fscore << score << std::endl;
  return 0;
}
